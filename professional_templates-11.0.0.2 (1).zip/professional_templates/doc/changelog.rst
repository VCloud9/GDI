.. _changelog:

Changelog
=========

`Version 0.2 (22 NOV 2017)`
-------------------------
- Fixed bugs concernign Print Button for Sales order, Picking Slip, Invoice and Purchase Reports

`Version 0.1 (11 OCT 2017)`
-------------------------
- New module for Odoo 11.0 community and Enterprise editions

